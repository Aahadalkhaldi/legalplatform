export const firebaseConfig = {
  apiKey: "AIzaSyBVXtDHaS3j4FeZsXllgcWu5o4Fg8FdJe4",
  authDomain: "legalplatform-a43f8.firebaseapp.com",
  projectId: "legalplatform-a43f8",
  storageBucket: "legalplatform-a43f8.appspot.com",
  messagingSenderId: "558959612033",
  appId: "1:558959612033:web:bb341b0477fd675f6b7d80"
};
